package servlet;

import model.Event;
import util.DBUtil;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.*;
import javax.servlet.http.*;

public class EventServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null)
            action = "list";
        try {
            switch (action) {
                case "new":
                    RequestDispatcher rd = request.getRequestDispatcher("eventForm.jsp");
                    rd.forward(request, response);
                    break;
                case "insert":
                    insertEvent(request, response);
                    break;
                case "delete":
                    deleteEvent(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "update":
                    updateEvent(request, response);
                    break;
                case "search":
                    searchEvents(request, response);
                    break;
                case "list":
                default:
                    listEvents(request, response);
                    break;
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void listEvents(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        List<Event> eventList = new ArrayList<>();
        Connection conn = DBUtil.getConnection();
        String sql = "SELECT * FROM Event";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        while (rs.next()) {
            Event event = new Event();
            event.setEventId(rs.getInt("event_id"));
            event.setEventName(rs.getString("event_name"));
            event.setLocation(rs.getString("location"));
            event.setCategory(rs.getString("category"));
            event.setDate(rs.getString("date"));
            event.setMaxCapacity(rs.getInt("max_capacity"));
            eventList.add(event);
        }
        rs.close();
        stmt.close();
        conn.close();
        request.setAttribute("eventList", eventList);
        RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
        rd.forward(request, response);
    }

    private void insertEvent(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        String eventName = request.getParameter("eventName");
        String date = request.getParameter("date");
        String location = request.getParameter("location");
        String category = request.getParameter("category");
        int maxCapacity = Integer.parseInt(request.getParameter("maxCapacity"));

        Connection conn = DBUtil.getConnection();
        String sql = "INSERT INTO Event (event_name, location, category, date, max_capacity) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, eventName);
        ps.setString(2, location);
        ps.setString(3, category);
        ps.setString(4, date);
        ps.setInt(5, maxCapacity);
        ps.executeUpdate();
        ps.close();
        conn.close();
        response.sendRedirect("EventServlet?action=list");
    }

    private void deleteEvent(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        int eventId = Integer.parseInt(request.getParameter("id"));
        Connection conn = DBUtil.getConnection();
        String sql = "DELETE FROM Event WHERE event_id=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, eventId);
        ps.executeUpdate();
        ps.close();
        conn.close();
        response.sendRedirect("EventServlet?action=list");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        int eventId = Integer.parseInt(request.getParameter("id"));
        Event event = new Event();
        Connection conn = DBUtil.getConnection();
        String sql = "SELECT * FROM Event WHERE event_id=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, eventId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            event.setEventId(rs.getInt("event_id"));
            event.setEventName(rs.getString("event_name"));
            event.setLocation(rs.getString("location"));
            event.setCategory(rs.getString("category"));
            event.setDate(rs.getString("date"));
            event.setMaxCapacity(rs.getInt("max_capacity"));
        }
        rs.close();
        ps.close();
        conn.close();
        request.setAttribute("event", event);
        RequestDispatcher rd = request.getRequestDispatcher("eventForm.jsp");
        rd.forward(request, response);
    }

    private void updateEvent(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, IOException {
        int eventId = Integer.parseInt(request.getParameter("eventId"));
        String eventName = request.getParameter("eventName");
        String date = request.getParameter("date");
        String location = request.getParameter("location");
        String category = request.getParameter("category");
        int maxCapacity = Integer.parseInt(request.getParameter("maxCapacity"));

        Connection conn = DBUtil.getConnection();
        String sql = "UPDATE Event SET event_name=?, location=?, category=?, date=?, max_capacity=? WHERE event_id=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, eventName);
        ps.setString(2, location);
        ps.setString(3, category);
        ps.setString(4, date);
        ps.setInt(5, maxCapacity);
        ps.setInt(6, eventId);
        ps.executeUpdate();
        ps.close();
        conn.close();
        response.sendRedirect("EventServlet?action=list");
    }

    private void searchEvents(HttpServletRequest request, HttpServletResponse response) 
            throws SQLException, ServletException, IOException {
        String category = request.getParameter("category");
        String fromDate = request.getParameter("fromDate");
        String toDate = request.getParameter("toDate");
        String eventName = request.getParameter("eventName");
        String location = request.getParameter("location");
        
        if ((category == null || category.trim().isEmpty()) &&
            (fromDate == null || fromDate.trim().isEmpty()) &&
            (toDate == null || toDate.trim().isEmpty()) &&
            (eventName == null || eventName.trim().isEmpty()) &&
            (location == null || location.trim().isEmpty())) {
            listEvents(request, response);
            return;
        }
        
        StringBuilder searchDetails = new StringBuilder();
        if (category != null && !category.trim().isEmpty()) {
            searchDetails.append("Category: ").append(category).append(" ");
        }
        if (fromDate != null && !fromDate.trim().isEmpty()) {
            searchDetails.append("From: ").append(fromDate).append(" ");
        }
        if (toDate != null && !toDate.trim().isEmpty()) {
            searchDetails.append("To: ").append(toDate).append(" ");
        }
        if (eventName != null && !eventName.trim().isEmpty()) {
            searchDetails.append("Event Name: ").append(eventName).append(" ");
        }
        if (location != null && !location.trim().isEmpty()) {
            searchDetails.append("Location: ").append(location).append(" ");
        }
        
        List<Event> eventList = new ArrayList<>();
        Connection conn = DBUtil.getConnection();
        
        StringBuilder sql = new StringBuilder("SELECT * FROM Event WHERE 1=1");
        if (category != null && !category.trim().isEmpty()) {
            sql.append(" AND category=?");
        }
        if (fromDate != null && !fromDate.trim().isEmpty()) {
            sql.append(" AND date >= ?");
        }
        if (toDate != null && !toDate.trim().isEmpty()) {
            sql.append(" AND date <= ?");
        }
        if (eventName != null && !eventName.trim().isEmpty()) {
            sql.append(" AND event_name LIKE ?");
        }
        if (location != null && !location.trim().isEmpty()) {
            sql.append(" AND location LIKE ?");
        }
        
        PreparedStatement ps = conn.prepareStatement(sql.toString());
        int index = 1;
        if (category != null && !category.trim().isEmpty()) {
            ps.setString(index++, category);
        }
        if (fromDate != null && !fromDate.trim().isEmpty()) {
            ps.setString(index++, fromDate);
        }
        if (toDate != null && !toDate.trim().isEmpty()) {
            ps.setString(index++, toDate);
        }
        if (eventName != null && !eventName.trim().isEmpty()) {
            ps.setString(index++, "%" + eventName + "%");
        }
        if (location != null && !location.trim().isEmpty()) {
            ps.setString(index++, "%" + location + "%");
        }
        
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Event event = new Event();
            event.setEventId(rs.getInt("event_id"));
            event.setEventName(rs.getString("event_name"));
            event.setLocation(rs.getString("location"));
            event.setCategory(rs.getString("category"));
            event.setDate(rs.getString("date"));
            event.setMaxCapacity(rs.getInt("max_capacity"));
            eventList.add(event);
        }
        rs.close();
        ps.close();
        conn.close();
        
        request.setAttribute("searchDetails", searchDetails.toString().trim());
        request.setAttribute("eventList", eventList);
        RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
        rd.forward(request, response);
    }
}
